<?php  
define("DB_NAME", "followdbirds");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_HOST", "localhost");
define("SYS_URL", "http://localhost/public_sc/Script");
define("DEBUGGING", true);
define("DEFAULT_LOCALE", "en_us");
define("LICENCE_KEY", "d3r2c5b7-5rf3-44x6-9d99-7052xxxx8689-9062");
?>