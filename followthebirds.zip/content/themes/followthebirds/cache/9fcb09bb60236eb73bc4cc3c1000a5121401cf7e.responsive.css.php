<?php
/* Smarty version 3.1.31, created on 2018-02-01 09:59:38
  from "/home/web/public_sc/Script/content/themes/default/css/responsive.css" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a72e50a689ba5_35409745',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e8ec91a7262aad1e187cfbc407b6c71dbeabadb9' => 
    array (
      0 => '/home/web/public_sc/Script/content/themes/default/css/responsive.css',
      1 => 1517471385,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 3600,
),true)) {
function content_5a72e50a689ba5_35409745 (Smarty_Internal_Template $_smarty_tpl) {
?>
/* CSS Document */

                           

@media (min-width:768px) {


}


@media (min-width:991px) {

			
}


@media (min-width:1200px) {

}

@media (min-width:1350px) {
		
}

@media (min-width:1280px) {


		
}	
@media (min-width:1921px) {

	#happy-member .happy-image-top{
		height: 217px;
		top: -3px;
	}
	#download-app:before{
		height: 195px;
		top: -176px;
	}

}






@media (max-width:1800px) {
	.banner-form{
		right: 4%;
	}
	.hero-slider .carousel-caption{
		left: 8%;
	}
	.hero-slider::after{
		height: 132px;
		bottom: -12px;
	}
	.banner-head-form p{
		padding: 10px 0;
	}
	.join-form{
		padding: 10px;
	}
	.form-group input[type="text"], .form-group input[type="email"], .form-group input[type="password"]{
		height: 40px;
	}
	.form-group{
		margin-bottom: 10px !important;
	}
}


@media (max-width:1600px) {

}


@media (max-width:1500px) {
	
	.container{
		width: 1300px !important;
	}
	.hero-slider .carousel-caption h3{
		font-size: 30px;
	}
	.hero-slider .carousel-caption h1{
		font-size: 77px;
	}
	.hero-slider .carousel-caption h1 span{
		font-size: 40px;
	}
	.hero-slider .carousel-caption h4{
		font-size: 30px;
	}
	.hero-slider .banner-caption-fixed{
		font-size: 330px;
	}
	.banner-form{
		width: 400px;
	}
	.banner-form h4{
		font-size: 18px;
	}
	.banner-head-form{
		width: 90%;
	}
	.banner-head-form p{
		font-size: 14px;
	}
	.banner-form{
		padding: 14px;
	}
	.sign-in-box{
		margin-top: 10px;
	}
	.banner-user-slider{
		margin-top: 13px;
	}
	.custom-btn{
		height: 30px;
		line-height: 14px !important;
	}
	.banner-form{
		top: 17%;
	}
	#how-its-work{
		padding: 114px 0 0px;
		height: 590px;
	}
	#happy-member .happy-image-top{
		 height: 110px;
         top: -3px;
	}
	h2{
		font-size: 34px !important;
	}
	.work-step-wrap{
		margin-top: 50px;
	}
	.step-text h5{
		font-size: 22px;
	}
	.gradient-btn{
		font-size: 16px;
	}
	.work-step-wrap{
		padding-bottom: 10px;
	}
	#happy-member h3{
		font-size: 30px;
	}
	#download-app h4{
		font-size: 28px;
		line-height: 36px;
	}
	.footer-image{
		width: 33%;
	}
	#download-app h4{
	   font-size: 25px;
       line-height: 36px;
	}
	.download-text{
	   padding-top: 0%;
	}
	#download-app p{
		    padding-top: 8px;
	}
	.app-store{
		    padding: 15px 0;
	}
	
	
}

@media (max-width:1365px){
	.container{
		width: 1150px !important;
	}
	.carousel-inner{
		height: 630px;
	}
	.carousel-inner > .item > img{
		height: 100% !important;
		width: auto !important;
	}
	.hero-slider::after{
		height: 93px;
        bottom: -13px;
	}
	.work-step-wrap{
		padding-left: 30px;
	}
	.step-main-wrap:nth-of-type(2){
		padding-left: 50px;
	}
	.small-dash{
		width: 44px;
	}
	.big-dash{
		width: 80px;
	}
	.step-main-wrap{
		margin-bottom: 30px;
		margin-bottom: 26px;
	}
	.step-text{
		width: 76%;
	}
	.step-text h5{
		font-size: 20px;
	}
	.gradient-btn{
		font-size: 15px;
	}
	#how-its-work{
		height: 520px;
	}

			 
}

@media (max-width:1149px){
	.container{
		width: 1000px !important;
	}
	.hero-slider .carousel-caption h1{
		font-size: 57px;
	}
	.hero-slider .carousel-caption h4{
		font-size: 27px;
		padding-left: 28%;
	}
	.hero-slider .banner-caption-fixed{
		font-size: 240px;
	}
	.left-gallery-wrap{
		width: 50% !important;
		padding-left: 5px !important;
		padding-right: 5px !important;
	}
	.work-right-wrap{
		width: 50% !important;
		padding-left: 5px !important;
		padding-right: 5px !important;
	}
	h2{
		font-size: 32px !important;
	}
	.work-step-wrap{
		margin-top: 22px;
	}
	.step-icon{
		width: 60px;
	}
	.step-text{
		width: 82%;
	}
	.step-text p{
		font-size: 14px;
	}
	.small-dash{
		top: 30px;
	}
	.big-dash{
		top: 130px;
	}
	.long-dash{
		height: 100px;
		top: 31px;
	}
	.gradient-btn{
		padding: 12px 30px;
	}
	#how-its-work{
		height: 460px;
	}
}

	
@media (max-width:1000px) {
	.container{
		width: 900px !important;
	}
	.banner-form{
		width: 42%;
    top: 21%;
    right: -54%;
    left: 0;
    margin: auto;
	}
	.hero-slider::after{
		display: none;
	}
	.hero-slider .carousel-caption{
		left: 26%;
		top: 20%;
	}
	.hero-slider .carousel-indicators{
		 bottom: 4%;
         left: 10%;
	}
	.left-gallery-wrap{
		width: 100% !important;
	}
	.work-right-wrap{
		width: 100% !important;
		padding-top: 10px;
	}
	#how-its-work{
		height:auto;
	}
	.happy-member-image{
		width: 140px;
		height: 140px;
	}
	.hero-slider .carousel-caption{
		left: 7%;
		top: 34%;
	}
	


}
@media (max-width:991px) {

.container{
		width: 740px !important;
	}
	.hero-slider .carousel-caption{
		left: 7%;
		top: 34%;
	}
	
	#download-app .container{
		width: 95% !important;
	}
	#download-app h4{
	   font-size: 18px;
       line-height: 24px;
	}
	#download-app p{
	   line-height: 20px;
		font-size: 14px;
	}
	.app-store a img{
		width: 120px;
	}
	.download-text{
		padding-left: 0 !important;
	}
	.hero-slider .carousel-caption h1{
	    font-size: 50px;	
	}
	.hero-slider .banner-caption-fixed{
		font-size: 215px;
	}
	.hero-slider .carousel-caption h4{
		font-size: 24px;
	}
	.hero-slider .carousel-caption h3{
		font-size: 26px;
	}

														 													  
}
	
@media (max-width:880px){

	.hero-slider .carousel-caption h1{
		 font-size: 46px;
		line-height: 42px;
	}
	.hero-slider .carousel-caption h1 span{
		font-size: 33px;
	}
	.hero-slider .carousel-caption h4{
		padding-left: 24%;
	}
}


@media (max-width:767px) {
	.carousel-inner{
		height: 100%;
	}
	.container{
		width: 95% !important;
	}
	#banner-slides{
		/*background: url(../images/banner-1.jpg) no-repeat;*/
		background-repeat: no-repeat;
		background-size: cover;
		padding-top: 90px;
		width: auto !important;
		padding-bottom: 60px;
		
	}
	.carousel-inner{
		display: none;
	}
	.banner-form{
		position: static;
		width: 60%;
	}
	.logo{
		width:262px;;
		margin: auto;
		padding-top: 5px;
	}
	.login-header{
		display: none;
	}
	.gallery-image{
		padding: 2px !important;
	}
	#how-its-work{
		    padding: 40px 0 40px;
		height: auto !important;
	}
	.work-right-wrap{
		background: rgba(255,255,255,0.6);
    padding: 20px !important;
		margin-top: 10px;
	}
	#happy-member .happy-image-top, #download-app:before{
		display: none;
	}
	#happy-member{
		padding: 10px 0 10px;
	}
	footer{
		padding: 20px 0;
	}
	.app-mobile{
		width: 250px;
	}
	#download-app{
		overflow: hidden;
	}
	.footer-image{
		 right: -128px;
		width: 50%;
	}
	.download-text{
		width: 80%;
	}
	.owl-buttons{
		padding-right: 0;
	}
																										
}

@media (max-width:730px){


}


@media (max-width:650px) {

	.banner-form{
		width: 80%;
	}
	#happy-member h3{
		font-size: 26px;
	}
	.happy-member-image{
		width: 150px;
		height: 150px;
	}
	#download-app p{
		display: none;
	}
	.footer-image{
		width: 60%;
	}
}
@media (max-width:585px) {
	
	.happy-member-image{
		width: 130px;
		height: 130px;
	}
								
}


@media (max-width:549px){
	.step-text{
		width: 78%;
	}
	h2{
		font-size: 28px !important;
	}
	.app-mobile{
		width: 200px;
	}

}
@media (max-width:480px) {
	.logo{
		width: 220px;
	}
	.banner-form{
		width: 80%;
	}
	#banner-slides{
		padding-bottom: 40px;
	}
	.work-step-wrap{
		padding-left: 0;
	}
	.small-dash{
		display: none;
	}
	.big-dash{
		display: none;
	}
	.long-dash{
		display: none;
	}
	.step-text{
		width: 100%;
		text-align: center;
		padding-top: 10px;
	}
	.step-icon{
		margin: auto;
		display: block;
		float: none;
	}
	.step-main-wrap:nth-of-type(2){
		padding-left: 15px;
		padding-right: 15px;
	}
	#how-its-work h2{
		text-align: center;
	}
	h2{
		font-size: 25px !important;
	}
	#how-its-work{
		text-align: center;
	}
	#how-its-work a.gradient-btn{
		display: inline-block;
	}
	.happy-member-image{
		width: 100px;
		height: 100px;
	}
	#happy-member h6{
		font-size: 16px;
	}
	#happy-member h3{
		font-size: 25px;
	}
	footer p{
		font-size: 13px;
	}
	.app-mobile{
		width: 150px;
		margin: auto;
	}
	.download-text{
		width: 100%;
		text-align: center;
	}

												
}
@media (max-width:423px){


}
	
@media (max-width:390px) {


}

@media (max-width:365px){


}

@media (max-width:345px){

}
@media (max-width:330px){

}




<?php }
}
